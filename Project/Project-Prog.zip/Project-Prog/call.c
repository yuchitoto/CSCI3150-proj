#include "call.h"
const char *HD = "HD";

int open_t(char *pathname)
{
	int inode_number;
	// write your code here.
	return inode_number;
}

int read_t(int inode_number, int offest, void *buf, int count)
{
	int read_bytes;
	// write your code here.
	return read_bytes; 
}

// you are allowed to create any auxiliary functions that can help your implementation. But only “open_t()” and "read_t()" are allowed to call these auxiliary functions.